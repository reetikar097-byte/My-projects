const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());

// ================= DATABASE =================

const DB_FILE = path.join(__dirname, "employees.json");

if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, "[]");
}

function getEmployees() {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

function saveEmployees(employees) {
    fs.writeFileSync(
        DB_FILE,
        JSON.stringify(employees, null, 2)
    );
}

function validId(id) {
    return Number.isSafeInteger(id) && id > 0;
}

// ================= BACKEND APIs =================

// GET ALL EMPLOYEES
app.get("/api/employees", (req, res) => {
    res.json(getEmployees());
});

// SEARCH EMPLOYEE
app.get("/api/employees/:id", (req, res) => {

    const id = Number(req.params.id);

    if (!validId(id)) {
        return res.status(400).json({
            message: "Invalid Employee ID"
        });
    }

    const employee = getEmployees().find(
        emp => emp.id === id
    );

    if (!employee) {
        return res.status(404).json({
            message: "Employee Not Found"
        });
    }

    res.json(employee);
});

// CREATE EMPLOYEE
app.post("/api/employees", (req, res) => {

    const { id, name } = req.body || {};

    if (
        !validId(id) ||
        typeof name !== "string" ||
        name.trim() === ""
    ) {
        return res.status(400).json({
            message: "Enter Valid Employee ID and Name"
        });
    }

    const employees = getEmployees();

    if (employees.some(emp => emp.id === id)) {
        return res.status(409).json({
            message: "Employee ID Already Exists"
        });
    }

    employees.push({
        id: id,
        name: name.trim()
    });

    saveEmployees(employees);

    res.status(201).json({
        message: "Employee Added Successfully"
    });
});

// UPDATE EMPLOYEE
app.put("/api/employees/:id", (req, res) => {

    const id = Number(req.params.id);
    const { name } = req.body || {};

    if (!validId(id)) {
        return res.status(400).json({
            message: "Invalid Employee ID"
        });
    }

    if (
        typeof name !== "string" ||
        name.trim() === ""
    ) {
        return res.status(400).json({
            message: "Enter Valid Employee Name"
        });
    }

    const employees = getEmployees();

    const employee = employees.find(
        emp => emp.id === id
    );

    if (!employee) {
        return res.status(404).json({
            message: "Employee Not Found"
        });
    }

    employee.name = name.trim();

    saveEmployees(employees);

    res.json({
        message: "Employee Updated Successfully"
    });
});

// DELETE EMPLOYEE
app.delete("/api/employees/:id", (req, res) => {

    const id = Number(req.params.id);

    if (!validId(id)) {
        return res.status(400).json({
            message: "Invalid Employee ID"
        });
    }

    const employees = getEmployees();

    const index = employees.findIndex(
        emp => emp.id === id
    );

    if (index === -1) {
        return res.status(404).json({
            message: "Employee Not Found"
        });
    }

    employees.splice(index, 1);

    saveEmployees(employees);

    res.json({
        message: "Employee Deleted Successfully"
    });
});

// ================= FRONTEND =================

app.get("/", (req, res) => {

res.send(`

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Employee Management Portal</title>

<style>

body {
    font-family: Arial, sans-serif;
    background-color: #f4f6f9;
    margin: 0;
}

header {
    background-color: #243b55;
    color: white;
    padding: 20px;
    text-align: center;
}

nav {
    background-color: #34495e;
    padding: 15px;
    text-align: center;
}

nav button {
    background: transparent;
    color: white;
    border: none;
    margin: 10px;
    font-size: 17px;
    cursor: pointer;
}

nav button:hover {
    color: yellow;
}

.container {
    width: 80%;
    max-width: 1000px;
    margin: 30px auto;
    background-color: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #ccc;
    box-sizing: border-box;
}

h2 {
    color: #243b55;
}

input {
    padding: 10px;
    margin: 10px;
    width: 220px;
    max-width: 90%;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    padding: 10px 20px;
    margin: 5px;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
}

button:hover {
    opacity: 0.8;
}

.create {
    background-color: green;
}

.update {
    background-color: #e67e22;
}

.delete {
    background-color: #e74c3c;
}

.search {
    background-color: #2980b9;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th {
    background-color: #243b55;
    color: white;
    padding: 12px;
}

td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

.table-wrapper {
    overflow-x: auto;
}

footer {
    background-color: #243b55;
    color: white;
    text-align: center;
    padding: 15px;
    margin-top: 40px;
}

/* HIDE ALL PAGES */

.page {
    display: none;
}

/* SHOW HOME PAGE FIRST */

#home {
    display: block;
}

</style>

</head>

<body>

<!-- HEADER -->

<header>
    <h1>Employee Management Portal</h1>
    <p>Manage Employee Records Easily</p>
</header>


<!-- NAVIGATION -->

<nav>

    <button onclick="showPage('home')">
        Home
    </button>

    <button onclick="showPage('registration')">
        Employee Registration
    </button>

    <button onclick="showPage('records')">
        Employee Records
    </button>

</nav>


<!-- ================= HOME PAGE ================= -->

<div class="container page" id="home">

    <h2>Welcome to Employee Management Portal</h2>

    <p>
        This portal allows you to create, update,
        delete and search employee records easily.
    </p>

    <h3>Our Services</h3>

    <ul>
        <li>Create Employee Records</li>
        <li>Update Employee Information</li>
        <li>Delete Employee Records</li>
        <li>Search Employee Details</li>
        <li>View All Employees</li>
    </ul>

    <h3>
        Total Employees:
        <span id="total">0</span>
    </h3>

    <br>

    <button class="create"
            onclick="showPage('registration')">
        Register Employee
    </button>

    <button class="search"
            onclick="showPage('records')">
        View Employee Records
    </button>

</div>


<!-- ============== REGISTRATION PAGE ============== -->

<div class="container page" id="registration">

    <h2>Employee Registration</h2>

    <label>Employee ID:</label>

    <input type="number"
           id="empId"
           min="1"
           step="1"
           placeholder="Enter Employee ID">

    <br>

    <label>Employee Name:</label>

    <input type="text"
           id="empName"
           placeholder="Enter Employee Name">

    <br><br>

    <!-- POST API -->
    <button class="create" onclick="addEmployee()">
        Create Employee
    </button>

    <!-- PUT API -->
    <button class="update" onclick="updateEmployee()">
        Update Employee
    </button>

    <!-- DELETE API -->
    <button class="delete" onclick="deleteEmployee()">
        Delete Employee
    </button>

    <br><br>

    <button class="search"
            onclick="showPage('records')">
        View Records
    </button>

</div>


<!-- ================= RECORDS PAGE ================= -->

<div class="container page" id="records">

    <h2>Employee Records</h2>

    <input type="number"
           id="searchId"
           placeholder="Search Employee ID">

    <!-- GET API BY ID -->
    <button class="search" onclick="searchEmployee()">
        Search
    </button>

    <!-- GET ALL API -->
    <button class="search" onclick="displayEmployees()">
        Show All
    </button>

    <div class="table-wrapper">

        <table>

            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody id="employeeTable">
            </tbody>

        </table>

    </div>

</div>


<!-- FOOTER -->

<footer>
    <p>Employee Management Portal | 2026</p>
</footer>


<!-- ================= JAVASCRIPT ================= -->

<script>

// BACKEND API
const API = "/api/employees";


// API REQUEST FUNCTION

async function apiRequest(url, options = {}) {

    const response = await fetch(url, options);

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || "Request Failed");
    }

    return data;
}


// SHOW SELECTED PAGE

function showPage(pageId) {

    const pages = document.getElementsByClassName("page");

    for (let i = 0; i < pages.length; i++) {
        pages[i].style.display = "none";
    }

    document.getElementById(pageId).style.display = "block";

    if (pageId === "records") {
        displayEmployees();
    }

    if (pageId === "home") {
        updateTotal();
    }
}


// CREATE EMPLOYEE - POST API

async function addEmployee() {

    const idValue = document.getElementById("empId").value;
    const id = Number(idValue);

    const name =
        document.getElementById("empName").value.trim();

    if (
        idValue === "" ||
        !Number.isSafeInteger(id) ||
        id <= 0 ||
        name === ""
    ) {
        alert("Please enter valid Employee ID and Name");
        return;
    }

    try {

        const result = await apiRequest(API, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                id: id,
                name: name
            })

        });

        alert(result.message);

        clearFields();

        showPage("records");

    } catch (error) {

        alert(error.message);

    }
}


// DISPLAY ALL EMPLOYEES - GET API

async function displayEmployees() {

    try {

        const employees = await apiRequest(API);

        showTable(employees);

        updateTotal();

    } catch (error) {

        alert(error.message);

    }
}


// DISPLAY TABLE

function showTable(employees) {

    const table = document.getElementById("employeeTable");

    table.innerHTML = "";

    if (employees.length === 0) {

        const row = table.insertRow();

        const cell = row.insertCell(0);

        cell.colSpan = 3;

        cell.textContent = "No Employee Records Found";

        return;
    }

    employees.forEach(function(employee) {

        const row = table.insertRow();

        row.insertCell(0).textContent = employee.id;

        row.insertCell(1).textContent = employee.name;

        const actionCell = row.insertCell(2);


        // EDIT BUTTON

        const editButton = document.createElement("button");

        editButton.textContent = "Edit";

        editButton.className = "update";

        editButton.onclick = function() {
            editEmployee(employee);
        };


        // DELETE BUTTON

        const deleteButton = document.createElement("button");

        deleteButton.textContent = "Delete";

        deleteButton.className = "delete";

        deleteButton.onclick = function() {
            removeEmployee(employee.id);
        };


        actionCell.appendChild(editButton);

        actionCell.appendChild(deleteButton);

    });
}


// UPDATE EMPLOYEE - PUT API

async function updateEmployee() {

    const idValue = document.getElementById("empId").value;
    const id = Number(idValue);

    const name =
        document.getElementById("empName").value.trim();

    if (
        idValue === "" ||
        !Number.isSafeInteger(id) ||
        id <= 0 ||
        name === ""
    ) {
        alert("Enter valid Employee ID and New Name");
        return;
    }

    try {

        const result = await apiRequest(API + "/" + id, {

            method: "PUT",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                name: name
            })

        });

        alert(result.message);

        clearFields();

        showPage("records");

    } catch (error) {

        alert(error.message);

    }
}


// DELETE EMPLOYEE BUTTON

function deleteEmployee() {

    const id = document.getElementById("empId").value;

    if (id === "") {
        alert("Please enter Employee ID");
        return;
    }

    removeEmployee(id);
}


// DELETE EMPLOYEE - DELETE API

async function removeEmployee(id) {

    if (!confirm("Are you sure you want to delete?")) {
        return;
    }

    try {

        const result = await apiRequest(API + "/" + id, {
            method: "DELETE"
        });

        alert(result.message);

        clearFields();

        await displayEmployees();

        await updateTotal();

    } catch (error) {

        alert(error.message);

    }
}


// SEARCH EMPLOYEE - GET API

async function searchEmployee() {

    const id = document.getElementById("searchId").value;

    if (id === "") {
        alert("Please enter Employee ID");
        return;
    }

    try {

        const employee = await apiRequest(API + "/" + id);

        showTable([employee]);

    } catch (error) {

        showTable([]);

        alert(error.message);

    }
}


// EDIT EMPLOYEE

function editEmployee(employee) {

    document.getElementById("empId").value = employee.id;

    document.getElementById("empName").value = employee.name;

    showPage("registration");
}


// CLEAR INPUT FIELDS

function clearFields() {

    document.getElementById("empId").value = "";

    document.getElementById("empName").value = "";
}


// UPDATE TOTAL EMPLOYEES - GET API

async function updateTotal() {

    try {

        const employees = await apiRequest(API);

        document.getElementById("total").textContent =
            employees.length;

    } catch (error) {

        console.error(error.message);

    }
}


// INITIAL LOAD
updateTotal();

</script>

</body>
</html>

`);

});

// ================= START SERVER =================

app.listen(PORT, "127.0.0.1", () => {

    console.log("Employee Management Portal Running");

    console.log("Open http://localhost:" + PORT);

});